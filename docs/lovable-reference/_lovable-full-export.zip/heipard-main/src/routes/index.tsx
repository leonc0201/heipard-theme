import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Truck, ShieldCheck, RotateCcw, Headphones, Sparkles } from "lucide-react";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { useReveal } from "@/hooks/use-reveal";
import { products } from "@/lib/products";

import hero from "@/assets/hero-evening.jpg";
import catLichter from "@/assets/cat-lichterketten.jpg";
import catEis from "@/assets/cat-eiszapfen.jpg";
import catParty from "@/assets/cat-party.jpg";
import catSolar from "@/assets/cat-solar.jpg";
import catCamping from "@/assets/cat-camping.jpg";
import catSmart from "@/assets/cat-smart.jpg";
import occWeih from "@/assets/occ-weihnachten.jpg";
import occGarten from "@/assets/occ-garten.jpg";
import occCamp from "@/assets/occ-camping.jpg";
import occHochzeit from "@/assets/occ-hochzeit.jpg";
import brandStory from "@/assets/brand-story.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "HeiPard – Lasse deine Welt erleuchten" },
      { name: "description", content: "Stimmungsvolle Lichterketten, Solar- & Outdoor-Beleuchtung. Versand aus Deutschland, bis zu 5 Jahre Garantie." },
      { property: "og:title", content: "HeiPard – Lasse deine Welt erleuchten" },
      { property: "og:description", content: "Stimmungsvolle Lichterketten, Solar- & Outdoor-Beleuchtung vom Niederrhein." },
    ],
  }),
  component: Home,
});

const categories = [
  { name: "Lichterketten", desc: "Klassisch & vielseitig", img: catLichter },
  { name: "Eiszapfen & Vorhang", desc: "Festlich am Fenster", img: catEis },
  { name: "Party & Terrasse", desc: "Stimmung für draußen", img: catParty },
  { name: "Solar & Gartendeko", desc: "Leuchtet ohne Steckdose", img: catSolar },
  { name: "Camping & Outdoor", desc: "Robust für unterwegs", img: catCamping },
  { name: "Smart Lighting", desc: "Per App gesteuert", img: catSmart },
];

const occasions = [
  { name: "Weihnachten", img: occWeih },
  { name: "Garten & Balkon", img: occGarten },
  { name: "Camping", img: occCamp },
  { name: "Hochzeit & Party", img: occHochzeit },
];

function Home() {
  useReveal();
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />

      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="relative h-[78vh] min-h-[600px] w-full">
          <img
            src={hero}
            alt="Garten am Sommerabend mit warmen Lichterketten"
            className="absolute inset-0 h-full w-full object-cover"
            width={1920}
            height={1280}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/65 via-black/25 to-black/10" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/40 to-transparent" />

          <div className="relative z-10 mx-auto flex h-full max-w-[1400px] flex-col justify-end px-6 pb-20 md:pb-28">
            <div className="max-w-2xl">
              <div className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-xs text-white/90 backdrop-blur-sm border border-white/15">
                <Sparkles className="h-3.5 w-3.5" style={{ color: "var(--brand)" }} />
                Saison 2026 — frisch eingetroffen
              </div>
              <h1
                className="mt-6 text-white text-5xl sm:text-6xl md:text-7xl leading-[1.02]"
                style={{ fontFamily: "var(--font-display)", fontWeight: 400 }}
              >
                Lasse deine Welt
                <br />
                <em className="not-italic" style={{ color: "oklch(0.88 0.13 70)" }}>
                  erleuchten.
                </em>
              </h1>
              <p className="mt-5 max-w-xl text-base md:text-lg text-white/80">
                Lichterketten, Solarlaternen und Camping-Lichter für Momente, an die du
                dich noch lange erinnerst.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link
                  to="/kollektion"
                  className="group inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3.5 text-sm font-medium text-primary-foreground glow-strong hover:scale-[1.02] transition-transform"
                >
                  Jetzt entdecken
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                </Link>
                <Link
                  to="/produkt/$slug"
                  params={{ slug: "edison-festoon-15" }}
                  className="inline-flex items-center gap-2 rounded-full border border-white/30 bg-white/5 px-7 py-3.5 text-sm font-medium text-white backdrop-blur-sm hover:bg-white/10 transition"
                >
                  Bestseller ansehen
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CATEGORY GRID */}
      <section className="mx-auto max-w-[1400px] px-6 py-20 md:py-28">
        <div className="flex items-end justify-between mb-10" data-reveal>
          <div>
            <div className="text-xs uppercase tracking-[0.18em] text-primary mb-3">
              Kollektionen
            </div>
            <h2 className="text-3xl md:text-5xl">Finde dein Licht</h2>
          </div>
          <Link to="/kollektion" className="hidden md:inline-flex items-center gap-2 text-sm text-foreground/80 hover:text-primary transition">
            Alles ansehen <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <BentoCategories />
      </section>

      {/* TRUST BAR */}
      <section className="border-y border-border bg-card/40">
        <div className="mx-auto max-w-[1400px] px-6 py-8 grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { i: Truck, t: "Versand aus Deutschland", s: "Schnell bei dir" },
            { i: ShieldCheck, t: "Bis zu 5 Jahre Garantie", s: "Auf ausgewählte Modelle" },
            { i: RotateCcw, t: "30 Tage Rückgaberecht", s: "Ohne Wenn und Aber" },
            { i: Headphones, t: "Service aus Deutschland", s: "Mo–Fr 9–16 Uhr" },
          ].map(({ i: Icon, t, s }) => (
            <div key={t} className="flex items-start gap-3">
              <Icon className="h-5 w-5 mt-0.5 text-primary shrink-0" />
              <div>
                <div className="text-sm font-medium text-foreground">{t}</div>
                <div className="text-xs text-muted-foreground">{s}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* BESTSELLER */}
      <section className="mx-auto max-w-[1400px] px-6 py-20 md:py-28">
        <div className="flex items-end justify-between mb-10" data-reveal>
          <div>
            <div className="text-xs uppercase tracking-[0.18em] text-primary mb-3">
              Bestseller
            </div>
            <h2 className="text-3xl md:text-5xl">Was unsere Kunden lieben</h2>
          </div>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {products.slice(0, 4).map((p) => (
            <ProductCard key={p.slug} p={p} />
          ))}
        </div>
      </section>

      {/* OCCASIONS */}
      <section className="mx-auto max-w-[1400px] px-6 py-20 md:py-24">
        <div className="mb-10" data-reveal>
          <div className="text-xs uppercase tracking-[0.18em] text-primary mb-3">
            Anlässe
          </div>
          <h2 className="text-3xl md:text-5xl max-w-xl">
            Für jeden Moment das passende Licht
          </h2>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {occasions.map((o, i) => (
            <Link
              key={o.name}
              to="/kollektion"
              data-reveal
              className="group relative overflow-hidden rounded-xl aspect-[3/4]"
              style={{ transitionDelay: `${i * 50}ms` }}
            >
              <img
                src={o.img}
                alt={o.name}
                loading="lazy"
                width={900}
                height={1200}
                className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1400ms] group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-5">
                <div
                  className="text-2xl text-white"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  {o.name}
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* BRAND STORY */}
      <section className="mx-auto max-w-[1400px] px-6 py-20 md:py-28">
        <div className="grid gap-12 md:grid-cols-2 items-center">
          <div className="relative" data-reveal>
            <div className="aspect-[5/4] overflow-hidden rounded-2xl glow-soft">
              <img
                src={brandStory}
                alt="Lichterketten werden im Wohnzimmer arrangiert"
                loading="lazy"
                width={1200}
                height={900}
                className="h-full w-full object-cover"
              />
            </div>
            <div
              className="absolute -bottom-4 -right-4 h-24 w-24 rounded-full opacity-60 blur-2xl"
              style={{ backgroundColor: "var(--glow)" }}
            />
          </div>
          <div data-reveal>
            <div className="text-xs uppercase tracking-[0.18em] text-primary mb-3">
              Über HeiPard
            </div>
            <h2 className="text-3xl md:text-5xl leading-tight">
              Heimat am Niederrhein. <br />
              <em className="not-italic text-primary">Licht für deine schönsten Stunden.</em>
            </h2>
            <p className="mt-6 text-base md:text-lg text-muted-foreground leading-relaxed">
              HeiPard ist zuhause am Niederrhein. Wir entwickeln Lichter, die Räume
              verwandeln und Abende verlängern. Jede Lichterkette wird geprüft, bevor sie
              zu dir reist — und unser Service spricht deine Sprache.
            </p>
            <Link to="/" className="mt-8 inline-flex items-center gap-2 text-sm text-foreground/85 hover:text-primary transition">
              Mehr über HeiPard <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* DEALER TEASER */}
      <section className="mx-auto max-w-[1400px] px-6 py-12">
        <div
          data-reveal
          className="rounded-2xl border border-border bg-card/60 px-8 py-7 flex flex-wrap items-center justify-between gap-5"
        >
          <div>
            <div className="text-sm font-medium text-foreground">Du bist Händler?</div>
            <div className="text-sm text-muted-foreground">
              Werde HeiPard-Partner und biete unsere Kollektion in deinem Geschäft an.
            </div>
          </div>
          <a className="inline-flex items-center gap-2 rounded-full border border-border bg-background px-5 py-2.5 text-sm font-medium hover:border-primary hover:text-primary transition">
            Partner werden <ArrowRight className="h-4 w-4" />
          </a>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}

function ProductCard({ p }: { p: (typeof products)[number] }) {
  return (
    <Link
      to="/produkt/$slug"
      params={{ slug: p.slug }}
      data-reveal
      className="group block"
    >
      <div className="relative aspect-square overflow-hidden rounded-xl bg-muted transition-all duration-500 group-hover:glow-strong">
        <img
          src={p.image}
          alt={p.name}
          loading="lazy"
          width={800}
          height={800}
          className="h-full w-full object-cover transition-transform duration-[1200ms] group-hover:scale-[1.04]"
        />
        <div
          className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-700 group-hover:opacity-100"
          style={{
            background:
              "radial-gradient(circle at 50% 60%, color-mix(in oklch, var(--glow) 25%, transparent), transparent 60%)",
          }}
        />
      </div>
      <div className="mt-4 flex items-start justify-between gap-4">
        <div>
          <div className="text-[15px] font-medium text-foreground">{p.name}</div>
          <div className="text-xs text-muted-foreground mt-0.5">{p.subtitle}</div>
        </div>
        <div className="text-[15px] font-medium text-foreground whitespace-nowrap">
          {p.price.toFixed(2).replace(".", ",")} €
        </div>
      </div>
    </Link>
  );
}

function BentoTile({
  name,
  desc,
  img,
  className,
}: {
  name: string;
  desc: string;
  img: string;
  className?: string;
}) {
  return (
    <Link
      to="/kollektion"
      data-reveal
      className={`group relative overflow-hidden rounded-2xl bg-card transition-all duration-500 hover:glow-strong ${className ?? ""}`}
    >
      <img
        src={img}
        alt={name}
        loading="lazy"
        className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1200ms] group-hover:scale-105"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/15 to-transparent" />
      <div className="absolute inset-x-0 bottom-0 p-5 md:p-6">
        <div className="text-xs text-white/70 mb-1">{desc}</div>
        <div
          className="text-xl md:text-2xl text-white"
          style={{ fontFamily: "var(--font-display)" }}
        >
          {name}
        </div>
        <div className="mt-2 inline-flex items-center gap-1.5 text-xs text-white/90 opacity-0 -translate-x-1 transition-all duration-500 group-hover:opacity-100 group-hover:translate-x-0">
          Entdecken <ArrowRight className="h-3 w-3" />
        </div>
      </div>
    </Link>
  );
}

function BentoCategories() {
  const c = Object.fromEntries(categories.map((x) => [x.name, x]));
  return (
    <div className="grid gap-4 md:gap-5 grid-cols-2 md:grid-cols-6 auto-rows-[180px] md:auto-rows-[200px]">
      <BentoTile {...c["Party & Terrasse"]} className="col-span-2 md:col-span-4 md:row-span-2" />
      <BentoTile {...c["Eiszapfen & Vorhang"]} className="col-span-2 md:col-span-2 md:row-span-3" />
      <BentoTile {...c["Lichterketten"]} className="col-span-1 md:col-span-2 md:row-span-2" />
      <BentoTile {...c["Solar & Gartendeko"]} className="col-span-1 md:col-span-2 md:row-span-2" />
      <BentoTile {...c["Camping & Outdoor"]} className="col-span-1 md:col-span-3 md:row-span-1" />
      <BentoTile {...c["Smart Lighting"]} className="col-span-1 md:col-span-3 md:row-span-1" />
    </div>
  );
}
