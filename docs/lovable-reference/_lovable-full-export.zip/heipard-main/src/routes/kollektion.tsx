import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronRight, SlidersHorizontal } from "lucide-react";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { products } from "@/lib/products";
import { useReveal } from "@/hooks/use-reveal";

export const Route = createFileRoute("/kollektion")({
  head: () => ({
    meta: [
      { title: "Lichterketten & Outdoor-Beleuchtung – HeiPard" },
      { name: "description", content: "Entdecke unsere komplette Kollektion: Lichterketten, Solarlampen, Camping-Laternen und Smart Lighting. Versand aus Deutschland." },
      { property: "og:title", content: "Kollektion – HeiPard" },
      { property: "og:description", content: "Stimmungsvolle Beleuchtung für drinnen, draußen und unterwegs." },
    ],
  }),
  component: Collection,
});

const filterGroups: { label: string; options: string[] }[] = [
  { label: "Stromquelle", options: ["Netz", "Solar", "Batterie", "Akku"] },
  { label: "Länge", options: ["bis 5 m", "5 – 10 m", "10 – 20 m", "über 20 m"] },
  { label: "Lichtfarbe", options: ["Warmweiß", "Kaltweiß", "Multicolor", "RGB"] },
  { label: "Einsatzbereich", options: ["Innen", "Außen"] },
  { label: "IP-Schutzart", options: ["IP20", "IP44", "IP54", "IP65"] },
];

function Collection() {
  useReveal();
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />

      {/* Breadcrumb + header */}
      <div className="mx-auto max-w-[1400px] px-6 pt-10 pb-6">
        <nav className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <Link to="/" className="hover:text-primary transition">Start</Link>
          <ChevronRight className="h-3 w-3" />
          <span>Kollektion</span>
          <ChevronRight className="h-3 w-3" />
          <span className="text-foreground">Lichterketten</span>
        </nav>
        <div className="mt-6 flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="text-4xl md:text-5xl">Lichterketten</h1>
            <p className="mt-3 text-muted-foreground max-w-xl">
              Warmweiße Klassiker, festliche Vorhänge, Solar-Laternen und mehr — sortiert
              nach dem, was zu deinem Abend passt.
            </p>
          </div>
          <div className="flex items-center gap-3 text-sm">
            <span className="text-muted-foreground">{products.length} Produkte</span>
            <span className="text-border">·</span>
            <label className="flex items-center gap-2">
              <span className="text-muted-foreground">Sortieren:</span>
              <select className="bg-transparent border border-border rounded-md px-3 py-1.5 text-sm outline-none focus:border-primary">
                <option>Empfohlen</option>
                <option>Preis aufsteigend</option>
                <option>Preis absteigend</option>
                <option>Neuheiten</option>
              </select>
            </label>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-[1400px] px-6 pb-20 grid gap-10 lg:grid-cols-[260px_1fr]">
        {/* Filters */}
        <aside className="lg:sticky lg:top-24 lg:self-start">
          <div className="flex items-center gap-2 text-xs uppercase tracking-[0.16em] text-primary mb-5">
            <SlidersHorizontal className="h-3.5 w-3.5" /> Filter
          </div>
          <div className="space-y-7">
            {filterGroups.map((g) => (
              <div key={g.label}>
                <div className="text-sm font-medium text-foreground mb-3">{g.label}</div>
                <ul className="space-y-2">
                  {g.options.map((o) => (
                    <li key={o}>
                      <label className="flex items-center gap-2.5 text-sm text-muted-foreground hover:text-foreground transition cursor-pointer">
                        <input
                          type="checkbox"
                          className="h-3.5 w-3.5 rounded border-border accent-[var(--primary)]"
                        />
                        {o}
                      </label>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </aside>

        {/* Grid */}
        <div className="grid gap-x-6 gap-y-10 sm:grid-cols-2 xl:grid-cols-3">
          {products.map((p) => (
            <Link
              key={p.slug}
              to="/produkt/$slug"
              params={{ slug: p.slug }}
              data-reveal
              className="group block"
            >
              <div className="relative aspect-square overflow-hidden rounded-xl bg-muted transition-all duration-500 group-hover:glow-strong">
                <img
                  src={p.image}
                  alt={p.name}
                  loading="lazy"
                  width={800}
                  height={800}
                  className="h-full w-full object-cover transition-transform duration-[1200ms] group-hover:scale-[1.04]"
                />
                <div
                  className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-700 group-hover:opacity-100"
                  style={{
                    background:
                      "radial-gradient(circle at 50% 60%, color-mix(in oklch, var(--glow) 28%, transparent), transparent 60%)",
                  }}
                />
                <div className="absolute top-3 left-3 inline-flex items-center gap-1.5 rounded-full bg-background/85 backdrop-blur px-2.5 py-1 text-[10px] uppercase tracking-wider text-foreground/75 border border-border">
                  {p.power}
                </div>
              </div>
              <div className="mt-4 flex items-start justify-between gap-4">
                <div>
                  <div className="text-[15px] font-medium text-foreground">{p.name}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">
                    {p.length} · {p.color}
                  </div>
                </div>
                <div className="text-[15px] font-medium text-foreground whitespace-nowrap">
                  {p.price.toFixed(2).replace(".", ",")} €
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      <SiteFooter />
    </div>
  );
}
