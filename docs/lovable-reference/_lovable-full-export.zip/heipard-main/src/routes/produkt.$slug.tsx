import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import {
  ChevronRight,
  Ruler,
  Zap,
  Droplet,
  Sun,
  ShieldCheck,
  Plus,
  Minus,
  Heart,
  ShoppingBag,
} from "lucide-react";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { findProduct, products } from "@/lib/products";
import { useReveal } from "@/hooks/use-reveal";
import scene1 from "@/assets/scene-1.jpg";
import scene2 from "@/assets/scene-2.jpg";
import featStimmung from "@/assets/feat-stimmung.jpg";
import featWetter from "@/assets/feat-wetter.jpg";
import featSetup from "@/assets/feat-setup.jpg";
import { Timer, Palette, Link2 } from "lucide-react";

export const Route = createFileRoute("/produkt/$slug")({
  loader: ({ params }) => {
    const product = findProduct(params.slug);
    if (!product) throw notFound();
    return { product };
  },
  head: ({ loaderData }) => {
    const p = loaderData?.product;
    return {
      meta: [
        { title: `${p?.name ?? "Produkt"} – HeiPard` },
        { name: "description", content: p?.subtitle ?? "" },
        { property: "og:title", content: `${p?.name ?? ""} – HeiPard` },
        { property: "og:description", content: p?.subtitle ?? "" },
        { property: "og:image", content: p?.image ?? "" },
      ],
    };
  },
  component: ProductDetail,
});

function ProductDetail() {
  useReveal();
  const { product } = Route.useLoaderData();
  const [active, setActive] = useState(0);
  const [qty, setQty] = useState(1);
  const [openAcc, setOpenAcc] = useState<string | null>("specs");

  const gallery = [product.image, scene1, scene2, product.image];
  const related = products.filter((p) => p.slug !== product.slug).slice(0, 4);

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />

      <div className="mx-auto max-w-[1400px] px-6 pt-8">
        <nav className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <Link to="/" className="hover:text-primary">Start</Link>
          <ChevronRight className="h-3 w-3" />
          <Link to="/kollektion" className="hover:text-primary">{product.category}</Link>
          <ChevronRight className="h-3 w-3" />
          <span className="text-foreground">{product.name}</span>
        </nav>
      </div>

      <div className="mx-auto max-w-[1400px] px-6 pt-8 grid gap-12 lg:grid-cols-[1.15fr_1fr]">
        {/* GALLERY */}
        <div className="grid grid-cols-[80px_1fr] gap-4">
          <div className="flex flex-col gap-3">
            {gallery.map((g, i) => (
              <button
                key={i}
                onClick={() => setActive(i)}
                className={[
                  "aspect-square overflow-hidden rounded-md border-2 transition",
                  active === i ? "border-primary" : "border-transparent opacity-70 hover:opacity-100",
                ].join(" ")}
              >
                <img src={g} alt="" loading="lazy" className="h-full w-full object-cover" />
              </button>
            ))}
          </div>
          <div className="relative aspect-square overflow-hidden rounded-2xl bg-muted">
            <img
              src={gallery[active]}
              alt={product.name}
              width={1200}
              height={1200}
              className="h-full w-full object-cover"
            />
            <div
              className="pointer-events-none absolute inset-0"
              style={{
                background:
                  "radial-gradient(circle at 50% 65%, color-mix(in oklch, var(--glow) 12%, transparent), transparent 60%)",
              }}
            />
          </div>
        </div>

        {/* INFO */}
        <div className="lg:pt-6">
          <div className="text-xs uppercase tracking-[0.18em] text-primary mb-3">
            {product.category}
          </div>
          <h1 className="text-4xl md:text-5xl leading-tight">{product.name}</h1>
          <p className="mt-3 text-base text-muted-foreground">{product.subtitle}</p>

          <div className="mt-7 text-3xl font-medium text-foreground">
            {product.price.toFixed(2).replace(".", ",")} €
          </div>
          <div className="mt-1 text-xs text-muted-foreground">
            Inkl. MwSt. · Versandkosten ab 4,90 € · Kostenlos ab 50 €
          </div>

          {/* Spec badges */}
          <div className="mt-8 grid grid-cols-2 gap-3">
            <Badge icon={Ruler} label="Länge" value={product.length} />
            <Badge icon={Zap} label="Stromquelle" value={product.power} />
            <Badge icon={Sun} label="Lichtfarbe" value={product.color} />
            <Badge icon={Droplet} label="Schutzart" value={product.ip} />
          </div>

          <div className="mt-6 flex items-center gap-2 text-sm text-secondary">
            <ShieldCheck className="h-4 w-4" />
            <span className="text-foreground/85">{product.warranty}</span>
          </div>

          {/* Buy */}
          <div className="mt-9 flex items-stretch gap-3">
            <div className="flex items-center rounded-full border border-border bg-card">
              <button
                onClick={() => setQty(Math.max(1, qty - 1))}
                className="grid place-items-center h-12 w-12 text-foreground/70 hover:text-primary transition"
                aria-label="Weniger"
              >
                <Minus className="h-4 w-4" />
              </button>
              <span className="w-8 text-center text-sm font-medium">{qty}</span>
              <button
                onClick={() => setQty(qty + 1)}
                className="grid place-items-center h-12 w-12 text-foreground/70 hover:text-primary transition"
                aria-label="Mehr"
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>
            <button className="group inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-primary px-7 text-sm font-medium text-primary-foreground glow-soft hover:glow-strong transition-shadow">
              <ShoppingBag className="h-4 w-4" />
              In den Warenkorb
            </button>
            <button
              aria-label="Merken"
              className="grid place-items-center h-12 w-12 rounded-full border border-border bg-card text-foreground/75 hover:text-primary hover:border-primary transition"
            >
              <Heart className="h-4 w-4" />
            </button>
          </div>

          {/* Description */}
          <div className="mt-10 prose-sm max-w-none">
            <p className="text-foreground/85 leading-relaxed">
              Eine Lichterkette, die mehr ist als Beleuchtung — sie erzeugt Stimmung.
              Robuste Verarbeitung, warmes Licht und eine Länge, die zu deinem Raum passt.
              Aufgebaut in wenigen Minuten, gemacht für viele Jahre.
            </p>
          </div>

          {/* Accordions */}
          <div className="mt-10 border-t border-border">
            {[
              { id: "specs", label: "Technische Details" },
              { id: "install", label: "Installation & Pflege" },
              { id: "ship", label: "Versand & Rückgabe" },
            ].map((a) => {
              const open = openAcc === a.id;
              return (
                <div key={a.id} className="border-b border-border">
                  <button
                    onClick={() => setOpenAcc(open ? null : a.id)}
                    className="flex w-full items-center justify-between py-5 text-left text-sm font-medium text-foreground"
                  >
                    {a.label}
                    <span className="text-muted-foreground transition-transform" style={{ transform: open ? "rotate(45deg)" : "none" }}>
                      <Plus className="h-4 w-4" />
                    </span>
                  </button>
                  <div
                    className="grid transition-[grid-template-rows] duration-500 ease-out"
                    style={{ gridTemplateRows: open ? "1fr" : "0fr" }}
                  >
                    <div className="overflow-hidden">
                      <div className="pb-6 text-sm text-muted-foreground leading-relaxed">
                        {a.id === "specs" && (
                          <dl className="grid grid-cols-2 gap-x-6 gap-y-2">
                            <dt>Länge</dt><dd className="text-foreground">{product.length}</dd>
                            <dt>Stromquelle</dt><dd className="text-foreground">{product.power}</dd>
                            <dt>Lichtfarbe</dt><dd className="text-foreground">{product.color}</dd>
                            <dt>Schutzart</dt><dd className="text-foreground">{product.ip}</dd>
                            <dt>Garantie</dt><dd className="text-foreground">{product.warranty}</dd>
                          </dl>
                        )}
                        {a.id === "install" && (
                          <p>
                            Einfaches Aufhängen mit beiliegenden Clips. Bei Verschmutzung mit
                            einem leicht feuchten Tuch reinigen — keine aggressiven Reiniger
                            verwenden. Vor dem Verstauen vollständig trocknen lassen.
                          </p>
                        )}
                        {a.id === "ship" && (
                          <p>
                            Versand innerhalb von 1–2 Werktagen aus Krefeld. Versandkosten ab
                            4,90 €, ab 50 € Bestellwert versandkostenfrei. 30 Tage
                            Rückgaberecht ohne Angabe von Gründen.
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* WARUM DU SIE LIEBEN WIRST */}
      <FeatureSection />

      {/* PASST DAZU */}
      <section className="mx-auto max-w-[1400px] px-6 pt-24 md:pt-32">
        <div className="mb-8" data-reveal>
          <div className="text-xs uppercase tracking-[0.18em] text-primary mb-3">
            Passt dazu
          </div>
          <h2 className="text-3xl md:text-4xl">Für eine noch schönere Stimmung</h2>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {related.map((p) => (
            <Link
              key={p.slug}
              to="/produkt/$slug"
              params={{ slug: p.slug }}
              data-reveal
              className="group block"
            >
              <div className="relative aspect-square overflow-hidden rounded-xl bg-muted transition-all duration-500 group-hover:glow-strong">
                <img
                  src={p.image}
                  alt={p.name}
                  loading="lazy"
                  width={800}
                  height={800}
                  className="h-full w-full object-cover transition-transform duration-[1200ms] group-hover:scale-[1.04]"
                />
              </div>
              <div className="mt-3 flex items-start justify-between gap-3">
                <div className="text-[14px] font-medium text-foreground">{p.name}</div>
                <div className="text-[14px] text-foreground whitespace-nowrap">
                  {p.price.toFixed(2).replace(".", ",")} €
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}

function Badge({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-start gap-3 rounded-xl border border-border bg-card/50 px-4 py-3">
      <Icon className="h-4 w-4 mt-0.5 text-primary shrink-0" />
      <div>
        <div className="text-[11px] uppercase tracking-wider text-muted-foreground">
          {label}
        </div>
        <div className="text-sm font-medium text-foreground">{value}</div>
      </div>
    </div>
  );
}

function FeatureSection() {
  const blocks = [
    {
      img: featStimmung,
      kicker: "Warmes Licht",
      title: "Licht, das den Abend verlängert.",
      body: "Das warmweiße Leuchten verwandelt deine Terrasse oder dein Wohnzimmer in einen Ort, an dem du gerne länger bleibst. Kein kaltes LED-Flackern, sondern echte Stimmung — so, wie du sie willst.",
    },
    {
      img: featWetter,
      kicker: "Gebaut für draussen",
      title: "Regen? Kein Thema.",
      body: "Vergossene Fassungen, robuste Kabel und IP-geprüfte Verbindungen halten Wetter aus, wenn dein Abend draußen länger wird. Lass sie hängen — auch wenn der Sommerregen kommt.",
    },
    {
      img: featSetup,
      kicker: "In Minuten aufgebaut",
      title: "Auspacken, aufhängen, anknipsen.",
      body: "Beiliegende Clips und ein durchdachtes Kabelmanagement machen das Aufhängen einfach. Innerhalb weniger Minuten leuchtet dein Abend — ohne Fummelei, ohne Werkzeugkiste.",
    },
  ];
  const minis = [
    { i: Timer, l: "Timer-Funktion", t: "6 Stunden an, 18 Stunden Pause" },
    { i: Palette, l: "8 Leuchtmodi", t: "Von ruhig bis festlich animiert" },
    { i: Link2, l: "Koppelbar", t: "Bis zu 4 Ketten miteinander verbinden" },
  ];
  return (
    <section className="mx-auto max-w-[1400px] px-6 pt-24 md:pt-32">
      <div className="mb-12 max-w-2xl" data-reveal>
        <div className="text-xs uppercase tracking-[0.18em] text-primary mb-3">
          Warum du sie lieben wirst
        </div>
        <h2 className="text-3xl md:text-5xl leading-tight">
          Kleine Details, <em className="not-italic text-primary">große Wirkung.</em>
        </h2>
      </div>

      <div className="space-y-20 md:space-y-28">
        {blocks.map((b, i) => {
          const reverse = i % 2 === 1;
          return (
            <div
              key={b.kicker}
              data-reveal
              className={`grid gap-8 md:gap-14 md:grid-cols-2 items-center ${reverse ? "md:[&>*:first-child]:order-2" : ""}`}
            >
              <div className="relative aspect-[5/4] overflow-hidden rounded-2xl glow-soft">
                <img
                  src={b.img}
                  alt={b.title}
                  loading="lazy"
                  width={1200}
                  height={960}
                  className="h-full w-full object-cover"
                />
              </div>
              <div className={reverse ? "md:pr-6" : "md:pl-6"}>
                <div className="text-xs uppercase tracking-[0.2em] text-primary mb-3">
                  {b.kicker}
                </div>
                <h3 className="text-2xl md:text-4xl leading-tight">{b.title}</h3>
                <p className="mt-5 text-base text-muted-foreground leading-relaxed max-w-lg">
                  {b.body}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-20 md:mt-28 grid gap-6 sm:grid-cols-3 border-t border-border pt-12">
        {minis.map(({ i: Icon, l, t }) => (
          <div key={l} data-reveal className="flex items-start gap-4">
            <Icon className="h-5 w-5 mt-1 text-primary shrink-0" />
            <div>
              <div className="text-sm font-medium text-foreground">{l}</div>
              <div className="text-sm text-muted-foreground mt-1">{t}</div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
