import { Link } from "@tanstack/react-router";
import { Search, ShoppingBag, User } from "lucide-react";
import { LightSwitch } from "./light-switch";

const nav = [
  { to: "/kollektion", label: "Lichterketten" },
  { to: "/kollektion", label: "Outdoor" },
  { to: "/kollektion", label: "Solar & Garten" },
  { to: "/kollektion", label: "Camping" },
  { to: "/kollektion", label: "Smart" },
];

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-[1400px] items-center gap-6 px-6">
        <Link to="/" className="flex items-center gap-1.5">
          <span
            className="text-2xl font-semibold tracking-tight"
            style={{ color: "var(--brand)", fontFamily: "var(--font-display)" }}
          >
            HeiPard
          </span>
          <span
            className="mt-1 inline-block h-1.5 w-1.5 rounded-full flicker"
            style={{
              backgroundColor: "var(--brand)",
              boxShadow: "0 0 10px var(--brand), 0 0 2px var(--brand)",
            }}
          />
        </Link>

        <nav className="ml-4 hidden lg:flex items-center gap-7 text-sm text-foreground/85">
          {nav.map((n) => (
            <Link
              key={n.label}
              to={n.to}
              className="relative py-1 transition-colors hover:text-primary"
            >
              {n.label}
            </Link>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-4">
          <LightSwitch />
          <button aria-label="Suche" className="hidden sm:block text-foreground/75 hover:text-primary transition-colors">
            <Search className="h-[18px] w-[18px]" />
          </button>
          <button aria-label="Konto" className="hidden sm:block text-foreground/75 hover:text-primary transition-colors">
            <User className="h-[18px] w-[18px]" />
          </button>
          <button aria-label="Warenkorb" className="relative text-foreground/75 hover:text-primary transition-colors">
            <ShoppingBag className="h-[18px] w-[18px]" />
            <span className="absolute -right-1.5 -top-1.5 grid h-4 w-4 place-items-center rounded-full bg-primary text-[10px] font-medium text-primary-foreground">
              2
            </span>
          </button>
        </div>
      </div>
    </header>
  );
}
