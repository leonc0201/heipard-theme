import { Link } from "@tanstack/react-router";

export function SiteFooter() {
  return (
    <footer className="mt-32 border-t border-border bg-card/50">
      <div className="mx-auto max-w-[1400px] px-6 py-16 grid gap-12 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-1.5">
            <span
              className="text-xl font-semibold"
              style={{ color: "var(--brand)", fontFamily: "var(--font-display)" }}
            >
              HeiPard
            </span>
            <span
              className="mt-1 inline-block h-1.5 w-1.5 rounded-full"
              style={{ backgroundColor: "var(--brand)", boxShadow: "0 0 8px var(--brand)" }}
            />
          </div>
          <p className="mt-4 text-sm text-muted-foreground leading-relaxed max-w-[260px]">
            Stimmungsvolle Beleuchtung vom Niederrhein. Für drinnen, draußen und unterwegs.
          </p>
        </div>

        <div>
          <h4 className="text-sm font-medium text-foreground mb-4" style={{ fontFamily: "var(--font-sans)" }}>
            Kategorien
          </h4>
          <ul className="space-y-2.5 text-sm text-muted-foreground">
            <li><Link to="/kollektion" className="hover:text-primary transition-colors">Lichterketten</Link></li>
            <li><Link to="/kollektion" className="hover:text-primary transition-colors">Solar & Garten</Link></li>
            <li><Link to="/kollektion" className="hover:text-primary transition-colors">Camping & Outdoor</Link></li>
            <li><Link to="/kollektion" className="hover:text-primary transition-colors">Smart Lighting</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-medium text-foreground mb-4" style={{ fontFamily: "var(--font-sans)" }}>
            Service
          </h4>
          <ul className="space-y-2.5 text-sm text-muted-foreground">
            <li>+49 (0) 2151 – 555 0123</li>
            <li>Mo–Fr 9–16 Uhr</li>
            <li>service@heipard.de</li>
            <li><a className="hover:text-primary transition-colors">Hilfe & FAQ</a></li>
            <li><a className="hover:text-primary transition-colors">Händler werden</a></li>
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-medium text-foreground mb-4">Bleib auf dem Laufenden</h4>
          <p className="text-sm text-muted-foreground mb-3">
            Neue Kollektionen, Inspirationen und 10 % auf deine erste Bestellung.
          </p>
          <form className="flex gap-2">
            <input
              type="email"
              placeholder="deine@email.de"
              className="flex-1 rounded-md border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
            />
            <button className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90 transition">
              Anmelden
            </button>
          </form>
        </div>
      </div>

      <div className="border-t border-border">
        <div className="mx-auto max-w-[1400px] px-6 py-5 flex flex-wrap items-center justify-between gap-3 text-xs text-muted-foreground">
          <div>© 2026 HeiPard — eine Marke der C&amp;L Handels GmbH</div>
          <div className="flex gap-5">
            <a className="hover:text-primary transition-colors">Impressum</a>
            <a className="hover:text-primary transition-colors">Datenschutz</a>
            <a className="hover:text-primary transition-colors">AGB</a>
            <a className="hover:text-primary transition-colors">Widerruf</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
